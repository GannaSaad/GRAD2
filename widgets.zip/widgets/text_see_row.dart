import 'package:flutter/material.dart';

import '../core/utils/app_textstyles.dart';

class TextSeeRow extends StatelessWidget {
  String firstText;

  TextSeeRow({super.key, required this.firstText});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          firstText,
          style: Theme.of(context).textTheme.headlineMedium,
        ),
        Spacer(),
        TextButton(
          onPressed: () {},
          child: Text("See All", style: AppTextStyles.medium14LightPrimary),
        ),
      ],
    );
  }
}
